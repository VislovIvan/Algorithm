import SwiftUI

@main
struct AlgorithmApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
}
