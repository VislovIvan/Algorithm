import SwiftUI
import Combine

struct StartView: View {
    @StateObject var vm = ViewModel()
    @State var nav = false
    @State private var isOnboarding = true
    
    private let decimalFormatter: NumberFormatter = {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        return formatter
    }()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                VStack(spacing: 30) {
                    VStack(spacing: 10) {
                        Text("ALGORITHM")
                            .foregroundColor(Color.white)
                            .font(.system(size: 50, weight: .heavy, design: .rounded))
                        
                        Text("of randomization of weights coefficients to assess the effectiveness")
                            .foregroundColor(Color.white)
                            .font(.system(size: 20, weight: .medium, design: .rounded))
                            .multilineTextAlignment(.center)
                    }
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("1. Enter the number of indicators 'p':")
                            .foregroundColor(Color.white)
                            .font(.system(size: 22, weight: .regular, design: .rounded))
                        
                        Text("You should enter a whole number in this field.\nExample: 3")
                            .foregroundColor(Color.gray)
                            .font(.system(size: 15, weight: .light, design: .rounded))
                        
                        TextField("", text: $vm.pStr)
                            .padding(8)
                            .frame(height: 35)
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.blue.gradient.opacity(0.6), lineWidth: 2))
                            .keyboardType(.decimalPad)
                            .onChange(of: vm.pStr, perform: { text in
                                vm.pStr = text.positiveNumber(fractionCount: 0)
                                guard let p = Int(vm.pStr) else { return }
                                if p > 2 { vm.setupXFields() }
                            })
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        Text("2. Enter the accuracy of weighting coefficients:")
                            .foregroundColor(Color.white)
                            .font(.system(size: 22, weight: .regular, design: .rounded))
                        
                        Text("The calculation step should be a number that is a multiple of the sum of the weight coefficients — this is one unit.\nExample: 0,1 or 0,5")
                            .foregroundColor(Color.gray)
                            .font(.system(size: 15, weight: .light, design: .rounded))

                        TextField("", text: $vm.kStr)
                            .padding(8)
                            .frame(height: 35)
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.blue.gradient.opacity(0.6), lineWidth: 2))
                            .keyboardType(.decimalPad)
                            .onChange(of: vm.kStr, perform: { text in
                                vm.kStr = text.positiveNumber(integerCount: 1, fractionCount: 4, allowLeadingZero: true)
                            })
                    }
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("3. Filtering the calculated array of coefficients by setting a system of inequalities — rows for filtering values.:")
                            .foregroundColor(Color.white)
                            .font(.system(size: 22, weight: .regular, design: .rounded))
                            .foregroundColor(.white)
                        
                        Text("- Inequalities are specified by symbols: <, >, <=, >=;\n- Inequality is separated by spaces from the arguments;\n- It is possible to enter several arguments separated by commas;\n- Arguments are the numbers of elements in the set;\n- Several rules are written separated by a comma and a space after it.\nExample: 1 < 3")
                            .foregroundColor(Color.gray)
                            .font(.system(size: 15, weight: .light, design: .rounded))
                        
                        TextField("", text: $vm.limits)
                            .padding(8)
                            .frame(height: 35)
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.blue.gradient.opacity(0.6), lineWidth: 2))
                            .keyboardType(.default)
                    }
                    
                    if vm.countFields > 0 {
                        HStack(alignment: .top, spacing: 10) {
                            ScrollView(.horizontal, showsIndicators: false) {
                                VStack(alignment: .leading, spacing: 10) {
                                    
                                    Text("(Optional) To calculate the total weight of a set of parameters, you can enter a sequence of weight coefficients — how important the element is in the overall sum of the set.")
                                        .foregroundColor(Color.white)
                                        .font(.system(size: 22, weight: .regular, design: .rounded))
                                        .foregroundColor(.white)

                                    Text("They are entered in the table of weight coefficient values. You can enter multiple sets.\nExample for four parameters: 0.1, 0.5, 0.3")
                                        .foregroundColor(Color.gray)
                                        .font(.system(size: 15, weight: .light, design: .rounded))
                                    
                                    HStack(spacing: 8) {
                                        Text("№")
                                            .frame(width: 20, alignment: .leading)
                                            .foregroundColor(.white)
                                        HStack {
                                            ForEach(0..<vm.countFields, id: \.self) { fieldIndex in
                                                Text("x\(fieldIndex + 1)")
                                                    .frame(maxWidth: .infinity, alignment: .leading)
                                                    .foregroundColor(.white)
                                            }
                                        }
                                    }
                                    
                                    VStack(spacing: 8) {
                                        ForEach(0..<vm.fieldGroups, id: \.self) { groupIndex in
                                            HStack(spacing: 8) {
                                                Text("\(groupIndex + 1)")
                                                    .frame(width: 20, alignment: .leading)
                                                    .foregroundColor(.white)
                                                ForEach(0..<vm.countFields, id: \.self) { fieldIndex in
                                                    VStack(spacing: 0) {
                                                        TextField("", text: $vm.xFields[groupIndex][fieldIndex])
                                                            .padding(2)
                                                            .frame(width: 120, height: 35)
                                                            .foregroundColor(.white)
                                                            .onChange(of: vm.xFields[groupIndex][fieldIndex]) { text in
                                                                let temp = text.positiveNumber(allowLeadingZero: true, allowNegative: true)
                                                                vm.xFields[groupIndex][fieldIndex] = temp
                                                            }
                                                        Divider()
                                                            .overlay(.white)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            VStack(spacing: 15) {
                                Button(action: {
                                    vm.fieldGroups  += 1
                                    vm.xFields.append(Array(repeating: "", count: vm.countFields))
                                }) {
                                    Image(systemName: "plus.square")
                                        .resizable()
                                        .frame(width: 25, height: 25)
                                }
                                .buttonStyle(.plain)
                                Button(action: {
                                    if vm.fieldGroups > 1 {
                                        vm.fieldGroups -= 1
                                        vm.xFields.removeLast()
                                    }
                                }) {
                                    Image(systemName: "minus.square")
                                        .resizable()
                                        .frame(width: 25, height: 25)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    Spacer()
                    
                    NavigationLink(isActive: $nav) {
                        ResultView(vm: vm)
                    } label: {
                        EmptyView()
                    }
                    
                    Button {
                        nav = vm.checkInput()
                    } label: {
                        Text("Next")
                            .foregroundColor(.white)
                            .frame(width: 150, height: 50, alignment: .center)
                            .background(Color.blue.gradient)
                            .cornerRadius(10)
                    }
                    .padding()
                }
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 25)
                .padding(.vertical, 30)
                .preferredColorScheme(.dark)
                if isOnboarding {
                    Onboarding(isOnboarding: $isOnboarding)
                }
            }
            .onTapGesture {
                UIApplication.shared.endEditing()
            }
            .navigationBarTitle(" ")
            .navigationBarTitleDisplayMode(.inline)
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .alert(item: $vm.alertItem) { alertItem in
            Alert(title: alertItem.title, message: alertItem.message, dismissButton: alertItem.dismissButton)
        }
    }
}

struct StartView_Previews: PreviewProvider {
    static var previews: some View {
        StartView()
    }
}
