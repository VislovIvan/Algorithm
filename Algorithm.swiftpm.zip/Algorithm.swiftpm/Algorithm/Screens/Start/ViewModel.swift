import SwiftUI

struct PData: Identifiable {
    let id = UUID()
    let x: Int
    let y: Float
}

struct ChartData: Identifiable {
    let id = UUID()
    let name: String
    let data: [PData]
}

class ViewModel: ObservableObject {
    @Published var calculating: Task<Void, Never>?
    @Published var result = [[Float]]()
    @Published var weights = [[Float]]()
    @Published var isProcessing = true
    @Published var alertItem: AlertItem?
    @Published var pStr: String = ""
    @Published var kStr: String = ""
    @Published var limits: String = ""
    
    var step: Double = 0
    @Published var countP: Int = 0
    var params: [(Int, String, Int)] = []
    
    @Published var fieldGroups = 1
    @Published var countFields = 0
    @Published var xFields: [[String]] = []
    @Published var chartData: [ChartData] = []
    
    var algorithm: MainAlgorithm?
    
    func setupXFields() {
        countFields = Int(pStr) ?? 0
        if xFields.isEmpty {
            xFields.append(Array(repeating: "", count: countFields))
        } else {
            for i in 0..<xFields.count {
                let count = xFields[i].count
                if countFields > count {
                    for _ in 1...(countFields-count) {
                        xFields[i].append("")
                    }
                } else {
                    xFields[i] = Array(xFields[i].prefix(countFields))
                }
            }
        }
    }
    
    func checkInput() -> Bool {
        if pStr.isEmpty {
            alertItem = AlertContext.emptyCountP
            return false
        }
        
        guard let p = Int(pStr) else {
            alertItem = AlertContext.incorrectCountP
            return false
        }
        
        if p < 3 {
            alertItem = AlertContext.incorrectCountP
            return false
        }
        
        if kStr.isEmpty  {
            alertItem = AlertContext.emptyAccurancy
            return false
        }
        guard let k = Double(kStr.replacingOccurrences(of: ",", with: ".")) else {
            alertItem = AlertContext.incorrectAccurancy
            return false
        }
        
        if k >= 1 || k <= 0 {
            alertItem = AlertContext.incorrectAccurancy
            return false
        }
        
        if limits.isEmpty {
            alertItem = AlertContext.emptyLimits
            return false
        }
        
        countP = p
        step = k
        params = filterParams(limits)
        if params.isEmpty {
            alertItem = AlertContext.incorrectLimits
            return false
        }
        isProcessing = true
        return true
    }
    
    
    func filterParams(_ ruleString: String) -> [(Int, String, Int)] {
        let rules = ruleString.components(separatedBy: ", ")
        var result: [(Int, String, Int)] = []
        
        for rule in rules {
            let parts = rule.components(separatedBy: " ")
            if parts.count == 3 {
                let arg1 = parts[0].split(separator: ",").compactMap { Int($0) }
                let arg2 = parts[2].split(separator: ",").compactMap { Int($0) }
                if !arg1.isEmpty && !arg2.isEmpty {
                    for a1 in arg1 {
                        for a2 in arg2 {
                            let op = parts[1]
                            result.append((a1 - 1, op, a2 - 1))
                        }
                    }
                }
            }
        }
        
        return result
    }
    
    
    func calculate() {
        calculating = Task {
            if countP > 2 {
                algorithm = MainAlgorithm()
                algorithm?.setup(step, countP: countP, params: params, x: xFields)
                self.algorithm?.calculate()
                await MainActor.run {
                    var result: [[Float]] = []
                    var weights: [[Float]] = []
                    var charts: [ChartData] = []
                    
                    for subArray in self.algorithm?.result ?? [[Float]]() {
                        result.append(Array(subArray.prefix(countP)))
                        weights.append(Array(subArray.suffix(subArray.count - countP)))
                    }
                    
                    self.result = result
                    self.weights = weights
                    for i in 0..<self.result.count {
                        var pDataArray: [PData] = []
                        for j in 0..<result[i].count {
                            let pData = PData(x: j, y: result[i][j])
                            pDataArray.append(pData)
                        }
                        let chartData = ChartData(name: "p\(i + 1)", data: pDataArray)
                        charts.append(chartData)
                    }
                    self.chartData = charts
                    self.isProcessing = false
                }
            }
        }
    }
    
    
    func stopCalculating() {
        algorithm?.stop = true
        algorithm = nil
        calculating = nil
    }
}


class MainAlgorithm {
    var max = 1
    var step = 1
    var deep: Int = 3
    
    var p: [Int] = [Int]()
    var conditions: [(Int, String, Int)] = []
    var xStr: [[String]] = []
    var findCount = 0
    var allCount = 0
    var prepearResult = [[Int]]()
    var result = [[Float]]()
    var stop = false
    
    func setup(_ k: Double, countP: Int, params: [(Int, String, Int)], x: [[String]]) {
        stop = false
        prepearResult = [[Int]]()
        p = Array(repeating: 0, count: countP)
        conditions = params.filter({ item in
            item.0 < countP && item.2 < countP
        })
        deep = countP
        xStr = x
        var k = k
        max = 1
        findCount = 0
        allCount = 0
        while k < 1 {
            k = k * 10
            step = Int(k)
            max = max * 10
        }
    }
    
    
    func calculate()  {
        findCombinations()
        result = prepearResult.map({ item in
            var arr = [Float]()
            item.forEach { x in
                arr.append(Float(x) / Float(max))
            }
            
            var xFloat = xStr.map { innerArr in
                innerArr.map { str in
                    Float(str) ?? 0
                }
            }
            
            let zeroValues = Array(repeating: Float(0), count: arr.count)
            while let index = xFloat.firstIndex(where: { $0 == zeroValues }) {
                xFloat.remove(at: index)
            }
            var weights: [Float] = []
            for i in 0..<xFloat.count {
                var value: Float = 0
                for j in 0..<arr.count {
                    value += xFloat[i][j] * arr[j]
                }
                weights.append(value)
            }
            arr.append(contentsOf: weights)
            return arr
        })
    }
    
    
    func findCombinations() {
        if stop  {
            return
        }
        if deep > 1 {
            deep -= 1
            for i in stride(from: step, to: max, by: step) {
                p[p.count - 1 - deep] = i
                findCombinations()
            }
            deep += 1
        }
        else {
            deep -= 1
            
            
            for i in stride(from: step, to: max, by: step) {
                p[p.count - 1] = i
                if blackBox(p: p, conditions: conditions) {
                    prepearResult.append(p)
                    //найденные комбинации
                    findCount += 1
                }
                //всего комбинаций
                allCount += 1
            }
            deep += 1
        }
    }
    
    private func blackBox(p: [Int], conditions: [(Int, String, Int)]) -> Bool {
        var result = false
        let sum = p.reduce(0) { $0 + $1 }
        if sum != max {
            return false
        }
        
        for (p1, op, p2) in conditions {
            switch op {
            case "<":
                if p[p1] < p[p2] {
                    result = true
                } else {
                    return false
                }
            case "<=":
                if p[p1] <= p[p2] {
                    result = true
                } else {
                    return false
                }
            case ">":
                if p[p1] > p[p2] {
                    result = true
                } else {
                    return false
                }
            case ">=":
                if p[p1] >= p[p2] {
                    result = true
                } else {
                    return false
                }
            case "=":
                if p[p1] == p[p2] {
                    result = true
                } else {
                    return false
                }
            case "<>":
                if p[p1] != p[p2] {
                    result = true
                } else {
                    return false
                }
            default:
                return false
            }
        }
        
        return result
    }
}
