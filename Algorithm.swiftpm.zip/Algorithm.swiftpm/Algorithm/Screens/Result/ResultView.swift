import SwiftUI
import Charts

struct ResultView: View {
    @ObservedObject  var vm: ViewModel
    @Environment(\.presentationMode) var presentationMode
    @State var isShowGraph = false
    @State private var isOnboardingDetail = true
    let yValues = stride(from: 0, to: 1.1, by: 0.1).map { $0 }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 0) {
                HStack(spacing: 0) {
                    Button(action: {
                        self.presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .frame(width: 30, height: 30)
                    }
                    .buttonStyle(.plain)
                    Text("Result")
                        .font(.system(size: 32, weight: .medium, design: .rounded))
                        .fontWeight(.medium)
                        .frame(maxWidth: .infinity)
                    Color.clear.frame(width: 30, height: 30)
                }
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            
            
            if vm.isProcessing {
                VStack {
                    ProgressView()
                    Text("Calculating the result of...")
                }
            } else {
                if vm.result.isEmpty {
                    Text("No combinations")
                } else {
                    VStack(spacing: 0) {
                        HStack(spacing: 50) {
                            Button {
                                isShowGraph = false
                            } label: {
                                Text("Table")
                                    .foregroundColor(isShowGraph ? .white : .black)
                                    .frame(width: 150, height: 50, alignment: .center)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .background(isShowGraph ? Color.blue : Color.white)
                            .cornerRadius(8)
                            
                            Button {
                                if vm.result.count < 450 {
                                    isShowGraph = true
                                } else {
                                    vm.alertItem = AlertContext.toManyData
                                }
                            } label: {
                                Text("Graphics")
                                    .foregroundColor(isShowGraph ? .black : .white)
                                    .frame(width: 150, height: 50, alignment: .center)
                                    .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .background(isShowGraph ? Color.white : Color.blue)
                            .cornerRadius(8)
                        }
                        .padding(.bottom, 25)
                        if isShowGraph {
                            Chart(vm.chartData, id: \.name) { series in
                                ForEach(series.data) { item in
                                    LineMark(x: .value("p", item.x),
                                             y: .value("value", item.y))
                                }
                                .foregroundStyle(by: .value("Name", series.name))
                                .symbol(by: .value("Name", series.name))
                                
                            }
                            .chartXAxis {
                                AxisMarks() {
                                    AxisGridLine()
                                }
                                
                            }
                            .chartYAxis {
                                AxisMarks(position: .leading, values: yValues)
                            }
                        } else {
                            ScrollView(.vertical, showsIndicators: false) {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    VStack(spacing: 2) {
                                        HStack(spacing: 2) {
                                            Text("№")
                                                .fontWeight(.medium)
                                                .frame(width: 65, height: 35)
                                                .background(Color.blue)
                                            
                                            HStack(spacing: 2) {
                                                ForEach(0..<vm.countP, id: \.self) { item in
                                                    Text("p\(item + 1)")
                                                        .frame(width: 65, height: 35)
                                                        .background(item % 2 == 0 ? Color.black : Color.black)
                                                }
                                            }
                                            if !vm.weights.isEmpty {
                                                HStack(spacing: 2) {
                                                    ForEach(0..<vm.weights[0].count, id: \.self) { item in
                                                        Text("q\(item + 1)")
                                                            .frame(width: 65, height: 35)
                                                            .background(item % 2 != 0 ? Color.black : Color.orange.opacity(0.8))
                                                    }
                                                }
                                            }
                                        }
                                        VStack(spacing: 2) {
                                            ForEach(Array(vm.result.enumerated()), id: \.offset) { index, element in
                                                HStack(spacing: 2) {
                                                    Text(String(format: "%d", index + 1))
                                                        .fontWeight(.medium)
                                                        .frame(width: 65, height: 35)
                                                        .background(Color.blue)
                                                    ForEach(Array(element.enumerated()), id: \.offset) { idx, item in
                                                        HStack(spacing: 2) {
                                                            Text(String(format: "%g", item))
                                                                .frame(width: 65, height: 35)
                                                                .background(idx % 2 == 0 ? Color.black : Color.black)
                                                        }
                                                    }
                                                    if !vm.weights.isEmpty {
                                                        ForEach(Array(vm.weights[index].enumerated()), id: \.offset) { idx, item in
                                                            HStack(spacing: 2) {
                                                                Text(String(format: "%g", item))
                                                                    .frame(width: 65, height: 35)
                                                                    .background(idx % 2 != 0 ? Color.black : Color.orange.opacity(0.8))
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 30)
                    .padding(.top, 75)
                }
            }
            if isOnboardingDetail {
                OnboardingDetail(isOnboardingDetail: $isOnboardingDetail)
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            vm.calculate()
        }
        .onDisappear {
            vm.stopCalculating()
        }
        .alert(item: $vm.alertItem) { alertItem in
            Alert(title: alertItem.title, message: alertItem.message, dismissButton: alertItem.dismissButton)
        }
    }
}
