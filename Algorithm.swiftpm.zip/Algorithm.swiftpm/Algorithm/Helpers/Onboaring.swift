import SwiftUI

struct Onboarding: View {
    @Binding var isOnboarding: Bool
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .edgesIgnoringSafeArea(.all)
            
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(Color.black.opacity(0.7))
                .frame(width: 500, height: 550)
                .overlay(
                    VStack(spacing: 16) {
                        Text("Hi!")
                            .foregroundColor(Color.white)
                            .font(.system(size: 40, weight: .heavy, design: .rounded))                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                        HStack {
                            Text("This is an algorithm for randomizing weight coefficients. It is used in the operation of neural networks, applied for optimization and evaluation of efficiency.\n\nI want to demonstrate how it works using the example of solving the problem of constructing rating systems.\n\nPlease, for the correct operation of the application, open it in full-screen format on your device!\n\nClick 'Start' to begin and fill in the data to obtain a model that describes a comprehensive assessment of efficiency.")
                                .foregroundColor(Color.white)
                                .font(.system(size: 18, weight: .semibold, design: .rounded))                            .foregroundColor(.white)
                                .multilineTextAlignment(.leading)
                            Spacer()
                        }
                        .padding(.leading, 10)
                        
                        Spacer()
                        
                        Button(action: {
                            isOnboarding = false
                        }) {
                            Text("Start")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding(.horizontal, 40)
                                .padding(.vertical, 15)
                                .background(Color.blue.gradient)
                                .cornerRadius(10)
                        }
                    }
                        .padding()
                )
        }
    }
}
