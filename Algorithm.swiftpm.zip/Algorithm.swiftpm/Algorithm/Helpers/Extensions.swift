import SwiftUI

extension UINavigationController {
    override open func viewDidLoad() {
        super.viewDidLoad()
        interactivePopGestureRecognizer?.delegate = nil
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension String {
    func positiveNumber(integerCount: Int? = nil, fractionCount: Int? = nil, allowLeadingZero: Bool = false, allowNegative: Bool = false) -> String {
        var sanitized: String = ""
        sanitized = self.replacingOccurrences(of: ",", with: ".")
        sanitized = sanitized.filter { $0.isNumber || $0 == "." }
        
        if !allowNegative {
            sanitized = sanitized.replacingOccurrences(of: "-", with: "")
        }
        
        let groups = sanitized.components(separatedBy: ".")
        var integerPart: String = ""
        var fractionPart: String = ""
        var isRemoveLeadingNulls = false
        var isAddDot = false
        
        for element in groups {
            if isRemoveLeadingNulls == false {
                if !element.isEmpty, let checkNotNull = Int(element) {
                    if allowLeadingZero == false {
                        integerPart = String(checkNotNull)
                    } else {
                        integerPart = element
                    }
                    isRemoveLeadingNulls = true
                }
            } else {
                isAddDot = true
                if !element.isEmpty {
                    fractionPart = fractionPart + element
                }
            }
        }
        
        var sanitizedIntegerPart = integerPart
        var sanitizedFractionPart = fractionPart
        
        if let count = integerCount {
            sanitizedIntegerPart = String(integerPart.prefix(count))
        }
        
        if let count = fractionCount {
            if count == 0 {
                isAddDot = false
                sanitizedFractionPart = ""
            } else {
                sanitizedFractionPart = String(fractionPart.prefix(count))
            }
        }
        
        var result = sanitizedIntegerPart
        
        if isAddDot {
            result += "." + sanitizedFractionPart
        }
        
        if !allowNegative {
            result = result.replacingOccurrences(of: "-", with: "")
        }
        
        return result
    }
    
    
}
