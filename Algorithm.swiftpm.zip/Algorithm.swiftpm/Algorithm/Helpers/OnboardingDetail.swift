import SwiftUI

struct OnboardingDetail: View {
    @Binding var isOnboardingDetail: Bool
    var body: some View {
        ZStack {
            Color(.systemBackground)
                .edgesIgnoringSafeArea(.all)
            
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(Color.black.opacity(0.7))
                .frame(width: 500, height: 650)
                .overlay(
                    VStack(spacing: 16) {
                        HStack {
                            Text("Now you will see the results of the algorithm's work. In columns p1 ... pn, the values of the weight category coefficients are selected, taking into account the imposed constraints. In the capital q, there is a comprehensive efficiency indicator.\n\nThis data can be used not only for analyzing efficiency but also for:\n    Sport: drawing lots and determining pairs of participants in tournaments;\n    Machine learning: randomization algorithms can be used to improve the training of models, for example, in random weight selection during neural network initialization or for selecting random subsets of data (bootstrap);\n    Optimization: in tasks where the best solution needs to be found among many possibilities; statistics: in research, randomization algorithms are used to test hypotheses and assess the impact of factors on the studied variables.\n\n    You can view the data on a chart by clicking on the 'Graphic' button.")
                                .foregroundColor(Color.white)
                                .font(.system(size: 18, weight: .semibold, design: .rounded))                            .foregroundColor(.white)
                                .multilineTextAlignment(.leading)
                            Spacer()
                        }
                        .padding(.leading, 10)
                        
                        Spacer()
                        
                        Button(action: {
                            isOnboardingDetail = false
                        }) {
                            Text("Start")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding(.horizontal, 40)
                                .padding(.vertical, 15)
                                .background(Color.blue.gradient)
                                .cornerRadius(10)
                        }
                    }
                        .padding()
                )
        }
    }
}
