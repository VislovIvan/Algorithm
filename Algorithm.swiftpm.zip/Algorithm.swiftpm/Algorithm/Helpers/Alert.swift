import SwiftUI

struct AlertItem: Identifiable {
    let id: UUID = UUID()
    let title: Text
    let message: Text
    let dismissButton: Alert.Button
}


struct AlertContext {
    static let emptyCountP = AlertItem(title: Text("Показатели"),
                                       message: Text("Введите количество показателей"),
                                       dismissButton: .default(Text("OK")))
    static let incorrectCountP = AlertItem(title: Text("Показатели"),
                                           message: Text("Минимальное количество показателей  должно равно 3"),
                                           dismissButton: .default(Text("OK")))
    static let emptyAccurancy = AlertItem(title: Text("Точность"),
                                          message: Text("Введите точность."),
                                          dismissButton: .default(Text("OK")))
    static let incorrectAccurancy = AlertItem(title: Text("Неверная точность"),
                                              message: Text("Тоность задается в диапазоне 0...1"),
                                              dismissButton: .default(Text("OK")))
    static let emptyLimits = AlertItem(title: Text("Ограничения"),
                                       message: Text("Введите ограничения"),
                                       dismissButton: .default(Text("OK")))
    static let incorrectLimits = AlertItem(title: Text("Ограничения"),
                                           message: Text("Неверно введены ограничения"),
                                           dismissButton: .default(Text("OK")))
    
    static let toManyData = AlertItem(title: Text("Графики"),
                                      message: Text("Слишком много данных для отображения"),
                                      dismissButton: .default(Text("OK")))
}
